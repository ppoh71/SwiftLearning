//: [Previous](@previous)
//: ## String initialization
//: Strings are often initialized using string literals
let theTruth = "Money can't buy me love."
//: One can also initialize empty strings
//: Here's one way to initialize an empty Swift string
var characterPoorString = ""
//: And here's another
let stringWithPotential = String()
//: [Next](@next)
