//: ## Strings
//: You've seen strings passed in to print statements
print("Hello, world!")

//: You've seen strings defined as variables and as constants
var myFavoriteAnimal = "nudibranch"
let encouragement = "You can do it!"
//: [Next](@next)
