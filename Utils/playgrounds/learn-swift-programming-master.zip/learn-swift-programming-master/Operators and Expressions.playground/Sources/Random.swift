import Foundation

public func randomBonus(from: Int, to: Int) -> Int {
    return 20
}
