//: ## Functions
//: basic function syntax
func nameOfFunction() {
    // body of function goes here
}
//: defining the "sayHello" function
func sayHello() {
    print("Hello!")
}
//: called "sayHello"
sayHello()
//: [Next](@next)
