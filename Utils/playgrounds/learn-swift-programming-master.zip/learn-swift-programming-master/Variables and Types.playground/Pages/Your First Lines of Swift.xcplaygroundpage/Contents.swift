//: ## Your First Lines of Swift
//: Example 1
var question = "Ready to write your first lines of Swift code?"
print(question)
//: Example 2
var response = "Yeah! I'm ready!"
print(response)
//: [Next](@next)
