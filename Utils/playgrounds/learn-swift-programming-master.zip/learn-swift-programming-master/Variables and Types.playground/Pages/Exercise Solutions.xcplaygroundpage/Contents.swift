//: [Previous](@previous)
//: ## Exercise Solutions
//: Practice: Hello World
print("Hello, world!")
//: Practice: Printing with Escape Characters
print("\"Hello\nWorld\"")
